/**
 * Created by EWilliams on 8/5/15.
 */
// Assignment 1 Output//
//SDI 1508 8/5/2015//
//Variable output based on photography//

var goodPhotograph = ("A good photograph is more than a focal point, but rather angles, depth, and colors.");//String variable defined//
console.log ("A good photograph is more than a focal point, but rather angles, depth, and colors.");// print string variable to console//
console.log (goodPhotograph + " It is also a matter of patience.");//concatenated statement with string variable for context//

var groupPhotos = 5;//define a number variable, using a good number of photos for a group.//
console.log (groupPhotos);//print variable only
console.log ("A popular number of photos for a group is " + groupPhotos);//[print a concatenated statement with number variable for context//

var pointAndShoot= false;// boolean variable defined
console.log (pointAndShoot);// print a false boolean variable
console.log ("True or False, Can you take the same type of pictures with a point and shoot camera as one with different lenses? " +  pointAndShoot);//boolean with concatenated statement for context//

var interchangableLense = true;//boolean variable defined
console.log (interchangableLense);//print a true boolean variable
console.log ("True or false, Are expensive cameras with different lense options worth the cost? " + interchangableLense);//print a concatenated statement to use a boolean variable//

var bestCamera =prompt ("Which type of Camera, do you perfer?  ");//define bestCamera as a user prompted answer
console.log ("Which type of Camera, do you perfer?");//print prompt statement
console.log (bestCamera);//print user response
console.log ("I prefer a Canon Rebel with 3 lenses when I take photos, but " + bestCamera + " is a good choice as well."); //concatenated final statement for context//

///End of code///

